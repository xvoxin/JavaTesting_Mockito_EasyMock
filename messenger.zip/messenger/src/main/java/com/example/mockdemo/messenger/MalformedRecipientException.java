package com.example.mockdemo.messenger;

public class MalformedRecipientException extends Exception {

}
