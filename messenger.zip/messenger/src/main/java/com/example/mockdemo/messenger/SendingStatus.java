package com.example.mockdemo.messenger;

public enum SendingStatus {
	
	SENT, SENDING_ERROR

}
