package com.example.mockdemo.messenger;

public enum ConnectionStatus {	
	SUCCESS, FAILURE	
}
